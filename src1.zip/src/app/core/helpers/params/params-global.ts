export const MAX_SIZE_UPLOAD_FILE = 300000;
export let GROUP_FORM_MODEL = [];
export let MENU_NOT_ACTION = [];
export let MONTH_LIST = [];
export let DAY_LIST_2 = [];
export let DAY_EDM_CULT = "Jeudi"
