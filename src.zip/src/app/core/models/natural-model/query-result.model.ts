export class QueryResultDataModel {
  success: boolean;
  data : any[];
  element
}

export class QueryResultOneDataModel{
  success: boolean;
  data : any
}
