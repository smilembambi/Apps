import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rem-edit',
  templateUrl: './rem-edit.component.html',
  styleUrls: ['./rem-edit.component.scss']
})
export class RemEditComponent  {

  origin: string = 'rem';

}
