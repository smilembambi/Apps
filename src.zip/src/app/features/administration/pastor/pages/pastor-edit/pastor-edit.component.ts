import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pastor-edit',
  templateUrl: './pastor-edit.component.html',
  styleUrls: ['./pastor-edit.component.scss']
})
export class PastorEditComponent {

  origin: string = 'pastor';

}
