export class LocationModel {
  lat: number;
  long: number
}
