export interface Task {
    id: number;
    title: string;
    date: string;
    task: string;
    user: string[];
    budget: number;
    status: string;
}
