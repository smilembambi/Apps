
/**** ICON ROUTE ****/
export const ROUTE_APP_ICON_CHURCH =  'bx bx-building-house';
export const ROUTE_APP_ICON_LOCAL_CHURCH =  'bx bx-building ';
export const ROUTE_APP_ICON_HOME_CHURCH =  'bx bx-home';
export const ROUTE_APP_ICON_MEMBER=  'bx bx-group';
export const ROUTE_APP_ICON_TRAINING =  'bx bx-book-content';
export const ROUTE_APP_ICON_EVANGELIZE =  'bx bx-volume-full';
export const ROUTE_APP_ICON_EVENTS =  'bx bx-volume-full';
export const ROUTE_APP_ICON_STAR =  'bx bx-user-pin';
export const ROUTE_APP_ICON_USER =  'bx bx-user';
export const ROUTE_APP_ICON_PASTOR =  'bx bx-user-voice';
export const ROUTE_APP_ICON_MINISTRY =  'bx bx-server';
export const ROUTE_APP_ICON_REM =  'bx bx-user-check';

