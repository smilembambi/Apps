export class FormModel {
  type: string;
  field:any;
  options:any;
  label:string;
  value:any;
  sizeColumn:string;
  isRequire: boolean;
  action: boolean;
  source: string;
  sType: string;
  group: string
  mask: any;
  placeholder: any;
  slotChar: any;
  id: any;
  file: any;
  editable: boolean;
  max:any;
  min:any;
  icon: any;
  multiple: any;

}
