import {ActionReducerMap, MetaReducer} from '@ngrx/store';
import {State} from './app.state';


export const reducers : ActionReducerMap<State> = {

}


export const metaReducers: MetaReducer<State>[] = [];
