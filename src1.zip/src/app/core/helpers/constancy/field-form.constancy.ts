export const addressField: any[] = [
  {id:'void',type:'void', isRequire:true,  value:'', label:'', field:'void', options:'',sizeColumn:'col-md-12'},
  {id:'address',type:'input', isRequire:true, value:'', label:'Adresse', field:'address', options:'',sizeColumn:'col-md-3'},
  {id:'arrondissement',type:'input', isRequire:true, value:'', label:'Arrondissement/Commune', field:'arrondissement', options:'',sizeColumn:'col-md-3'},
  {id:'void',type:'void', isRequire:true,  value:'', label:'', field:'void', options:'',sizeColumn:'col-md-12'},
  {id:'city',type:'input', isRequire:true, value:'', label:'Ville', field:'city', options:'',sizeColumn:'col-md-3'},
  {id:'country',type:'input', isRequire:true, value:'', label:'Pays', field:'country', options:'',sizeColumn:'col-md-3'},
  {id:'void',type:'void', isRequire:true,  value:'', label:'', field:'void', options:'',sizeColumn:'col-md-12'},
];




