export class StoryEventModel {
  _id: string;
  type: string ; // Decès, Bapteme, Mariage, Validation formation,
  dateEvent: string;
  placeEvent: string;
}
