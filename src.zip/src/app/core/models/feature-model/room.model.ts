export class RoomModel {
  _id: string;
  label : string;
}
