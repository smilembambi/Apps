import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-star-edit',
  templateUrl: './star-edit.component.html',
  styleUrls: ['./star-edit.component.scss']
})
export class StarEditComponent {

  origin: string = 'star';

}
