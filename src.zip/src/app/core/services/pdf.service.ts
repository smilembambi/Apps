import { Injectable } from '@angular/core';
import * as jsPDF from 'jspdf';
//import {jsPDF} from "jspdf";

@Injectable({
  providedIn: 'root'
})
export class PdfService {

}
